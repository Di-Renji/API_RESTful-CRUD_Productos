package com.org.Productos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductosRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductosRestApplication.class, args);
	}

}
